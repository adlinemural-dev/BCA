import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Sparkles, Rocket, Lightbulb, Wrench, Target, Star } from 'lucide-react';

interface AboutUsProps {
  onBack: () => void;
}

export default function AboutUs({ onBack }: AboutUsProps) {
  const playClickSound = () => {
    console.log('Click sound played');
  };

  const handleBack = () => {
    playClickSound();
    onBack();
  };

  const sections = [
    {
      icon: Sparkles,
      title: 'VISIONARIES - The Power Behind Tomorrow\'s Tech',
      content: 'Welcome to Visionaries, the official community of BCA innovators, creators, and changemakers. We\'re not just a club - we\'re a movement of curious minds shaping the future of technology with creativity, teamwork, and vision.',
    },
    {
      icon: Rocket,
      title: 'Who We Are',
      content: 'We are the Visionaries - the heart of the BCA community. A team of passionate learners, tech lovers, designers, and leaders who believe in turning imagination into innovation. For us, learning goes beyond the classroom - it\'s about exploring ideas, experimenting with technology, and growing together through every challenge.',
    },
    {
      icon: Lightbulb,
      title: 'Our Vision',
      content: 'To inspire, innovate, and ignite the next generation of tech pioneers. We dream of a community where every student is encouraged to explore, experiment, and evolve into a true visionary.',
    },
    {
      icon: Wrench,
      title: 'What We Do',
      content: 'Organize Tech Events & Hackathons that challenge, empower, and inspire.\nCreate Digital Campaigns & Video Projects that highlight creativity and storytelling.\nHost Workshops, Seminars & Guest Talks with experts from the tech world.\nConduct Cultural & Fun Events that blend art and technology.\nBuild Teamwork, Leadership & Real-world Skills among every member.',
    },
    {
      icon: Target,
      title: 'Our Motto',
      content: '"Think. Create. Execute."\nWe don\'t just dream about the future - we design it. Each member of Visionaries is a spark of innovation, and together, we light the way forward.',
    },
    {
      icon: Star,
      title: 'Why Visionaries?',
      content: 'Because we\'re more than coders, designers, or developers - we\'re visionaries who see beyond screens and scripts. We believe in technology that transforms lives, and we dare to make the impossible possible.',
    },
  ];

  return (
    <div className="min-h-screen py-16 px-8 relative" style={{ zIndex: 10 }}>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <h1 
          className="text-4xl md:text-6xl font-tech font-bold text-center mb-4 text-primary"
          style={{
            textShadow: '0 0 30px rgba(0, 188, 212, 0.5)',
          }}
        >
          ABOUT US
        </h1>
        <p className="text-center text-muted-foreground mb-16 text-lg font-display">
          Where imagination meets execution
        </p>

        <div className="space-y-8">
          {sections.map((section, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 hover-elevate">
                <div className="flex items-start gap-4">
                  <div 
                    className="p-3 rounded-md bg-primary/10"
                    style={{
                      boxShadow: '0 0 15px rgba(0, 188, 212, 0.2)',
                    }}
                  >
                    <section.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-xl font-tech font-bold text-foreground mb-3">
                      {section.title}
                    </h2>
                    <div 
                      className="w-24 h-0.5 mb-4"
                      style={{
                        background: 'linear-gradient(90deg, rgba(0, 188, 212, 0.8), transparent)',
                      }}
                    />
                    <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
                      {section.content}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-center pt-8"
          >
            <p className="text-2xl font-display italic text-foreground mb-2">
              "The Spirit of Visionaries"
            </p>
            <p className="text-lg text-muted-foreground mb-8">
              Where imagination meets execution,<br />
              where passion meets purpose,<br />
              and where every idea grows into innovation.
            </p>
            <p className="text-xl font-tech font-bold text-primary">
              Welcome to VISIONARIES — The Class. The Code. The Creativity.
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex justify-center mt-16"
        >
          <Button
            data-testid="button-back-to-home"
            onClick={handleBack}
            variant="outline"
            size="lg"
            className="px-8 py-6 text-lg font-display"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Home
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
