import { motion } from 'framer-motion';
import { Users, Info, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface NavigationButtonsProps {
  onNavigate: (page: 'team' | 'about' | 'activities') => void;
}

export default function NavigationButtons({ onNavigate }: NavigationButtonsProps) {
  const playClickSound = () => {
    console.log('Click sound played');
  };

  const handleClick = (page: 'team' | 'about' | 'activities') => {
    playClickSound();
    onNavigate(page);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.5 }}
      className="fixed bottom-20 left-0 right-0 flex flex-col md:flex-row items-center justify-center gap-6 px-8"
      style={{ zIndex: 20 }}
    >
      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Button
          data-testid="button-team-members"
          onClick={() => handleClick('team')}
          variant="default"
          size="lg"
          className="group relative px-8 py-6 text-lg font-display font-semibold"
          style={{
            boxShadow: '0 0 20px rgba(0, 188, 212, 0.4)',
          }}
        >
          <Users className="mr-2 h-5 w-5" />
          Team Members
        </Button>
      </motion.div>

      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Button
          data-testid="button-about-us"
          onClick={() => handleClick('about')}
          variant="default"
          size="lg"
          className="group relative px-8 py-6 text-lg font-display font-semibold"
          style={{
            boxShadow: '0 0 20px rgba(0, 188, 212, 0.4)',
          }}
        >
          <Info className="mr-2 h-5 w-5" />
          About Us
        </Button>
      </motion.div>

      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Button
          data-testid="button-what-we-do"
          onClick={() => handleClick('activities')}
          variant="default"
          size="lg"
          className="group relative px-8 py-6 text-lg font-display font-semibold"
          style={{
            boxShadow: '0 0 20px rgba(0, 188, 212, 0.4)',
          }}
        >
          <Zap className="mr-2 h-5 w-5" />
          What We Do
        </Button>
      </motion.div>
    </motion.div>
  );
}
