import { useState, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import { Scissors, Target } from 'lucide-react';

interface RibbonCuttingProps {
  onComplete: () => void;
}

export default function RibbonCutting({ onComplete }: RibbonCuttingProps) {
  const [isCut, setIsCut] = useState(false);
  const [isNearTarget, setIsNearTarget] = useState(false);
  const constraintsRef = useRef(null);
  
  const ribbonCenterX = typeof window !== 'undefined' ? window.innerWidth / 2 : 640;
  const ribbonY = typeof window !== 'undefined' ? window.innerHeight / 2 : 300;
  
  const x = useMotionValue(100);
  const y = useMotionValue(ribbonY + 100);

  const handleDrag = () => {
    const currentX = x.get();
    const currentY = y.get();
    
    const distance = Math.sqrt(
      Math.pow(currentX - ribbonCenterX, 2) +
      Math.pow(currentY - ribbonY, 2)
    );

    if (distance < 80) {
      setIsNearTarget(true);
    } else {
      setIsNearTarget(false);
    }
  };

  const handleDragEnd = () => {
    const currentX = x.get();
    const currentY = y.get();
    
    const distance = Math.sqrt(
      Math.pow(currentX - ribbonCenterX, 2) +
      Math.pow(currentY - ribbonY, 2)
    );

    if (distance < 80) {
      setIsCut(true);
      setTimeout(() => {
        onComplete();
      }, 1500);
    }
  };

  return (
    <div ref={constraintsRef} className="fixed inset-0 flex items-center justify-center overflow-hidden" style={{ zIndex: 10 }}>
      <AnimatePresence>
        {!isCut && (
          <motion.div
            key="ribbon-and-target"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="absolute w-full h-2 bg-primary"
              style={{ top: ribbonY, boxShadow: '0 0 20px rgba(0, 188, 212, 0.6)' }}
            />
            
            <motion.div
              className="absolute"
              style={{ 
                left: ribbonCenterX - 40, 
                top: ribbonY - 40,
              }}
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: isNearTarget ? 1 : 0.6,
              }}
              transition={{ 
                scale: { duration: 1.5, repeat: Infinity },
                opacity: { duration: 0.3 }
              }}
            >
              <Target 
                size={80} 
                className="text-primary"
                style={{
                  filter: 'drop-shadow(0 0 15px rgba(0, 188, 212, 0.6))',
                }}
              />
              <motion.div
                className="absolute inset-0 rounded-full border-2 border-primary"
                animate={{
                  scale: [1, 1.5],
                  opacity: [0.8, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeOut",
                }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {isCut && (
        <>
          <motion.div
            className="absolute h-2 bg-primary"
            style={{ 
              top: ribbonY, 
              left: 0, 
              width: '50%',
              boxShadow: '0 0 20px rgba(0, 188, 212, 0.6)' 
            }}
            initial={{ x: 0 }}
            animate={{ x: -200, rotate: -15 }}
            transition={{ duration: 0.8 }}
          />
          <motion.div
            className="absolute h-2 bg-primary"
            style={{ 
              top: ribbonY, 
              right: 0, 
              width: '50%',
              boxShadow: '0 0 20px rgba(0, 188, 212, 0.6)' 
            }}
            initial={{ x: 0 }}
            animate={{ x: 200, rotate: 15 }}
            transition={{ duration: 0.8 }}
          />
        </>
      )}

      <motion.div
        drag
        dragConstraints={constraintsRef}
        dragElastic={0.1}
        dragTransition={{ bounceStiffness: 300, bounceDamping: 20 }}
        onDrag={handleDrag}
        onDragEnd={handleDragEnd}
        style={{ 
          x,
          y,
          zIndex: 20,
        }}
        className="absolute cursor-grab active:cursor-grabbing"
        whileHover={{ scale: 1.15 }}
        whileDrag={{ scale: 1.05 }}
      >
        <motion.div
          animate={{
            rotate: isNearTarget ? -45 : -30,
          }}
          transition={{ duration: 0.2 }}
        >
          <Scissors 
            size={72} 
            className={`${isNearTarget ? 'text-accent' : 'text-primary'} transition-colors duration-300`}
            style={{
              filter: `drop-shadow(0 0 ${isNearTarget ? '20px' : '10px'} rgba(0, 188, 212, 0.8))`,
            }}
          />
        </motion.div>
      </motion.div>

      <div className="absolute bottom-20 text-center w-full">
        <motion.p
          className="text-muted-foreground text-lg font-display"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          Drag the scissors to the target to cut the ribbon
        </motion.p>
      </div>
    </div>
  );
}
