import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

interface TeamMemberProps {
  name: string;
  role: string;
  description: string;
  imagePath: string;
  delay?: number;
}

export default function TeamMember({ name, role, description, imagePath, delay = 0 }: TeamMemberProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -8 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card 
        className="p-6 hover-elevate transition-all duration-300"
        style={{
          boxShadow: isHovered ? '0 0 30px rgba(0, 188, 212, 0.4)' : undefined,
        }}
      >
        <div className="flex flex-col items-center text-center">
          <motion.div 
            className="w-40 h-40 rounded-full overflow-hidden mb-4 border-2 border-primary/30"
            style={{
              boxShadow: '0 0 20px rgba(0, 188, 212, 0.3)',
            }}
            animate={{
              boxShadow: isHovered 
                ? '0 0 35px rgba(0, 188, 212, 0.6)' 
                : '0 0 20px rgba(0, 188, 212, 0.3)',
              scale: isHovered ? 1.05 : 1,
            }}
            transition={{ duration: 0.3 }}
          >
            <img 
              src={imagePath} 
              alt={name}
              className="w-full h-full object-cover"
            />
          </motion.div>
          
          <motion.h3 
            className="text-xs uppercase tracking-widest text-primary font-display font-semibold mb-1"
            animate={{
              textShadow: isHovered 
                ? '0 0 10px rgba(0, 188, 212, 0.8)' 
                : '0 0 0px rgba(0, 188, 212, 0)',
            }}
          >
            {role}
          </motion.h3>
          
          <h2 className="text-2xl font-tech font-bold text-foreground mb-3">
            {name}
          </h2>
          
          <motion.div 
            className="h-0.5 mb-4"
            animate={{
              width: isHovered ? '80px' : '64px',
            }}
            transition={{ duration: 0.3 }}
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(0, 188, 212, 0.8), transparent)',
            }}
          />
          
          <p className="text-sm text-muted-foreground leading-relaxed">
            {description}
          </p>
        </div>
      </Card>
    </motion.div>
  );
}
