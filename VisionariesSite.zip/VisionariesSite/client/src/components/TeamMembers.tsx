import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import TeamMember from './TeamMember';
import image1 from '@assets/1.jpg_1761971842024.jpeg';
import image2 from '@assets/2.jpg_1761971849906.jpeg';
import image3 from '@assets/3.jpg_1761971857922.jpeg';
import image4 from '@assets/4.jpg_1761971866239.jpeg';
import image5 from '@assets/5.jpg_1761971873765.jpeg';

interface TeamMembersProps {
  onBack: () => void;
}

export default function TeamMembers({ onBack }: TeamMembersProps) {
  const playClickSound = () => {
    console.log('Click sound played');
  };

  const handleBack = () => {
    playClickSound();
    onBack();
  };

  const teamData = [
    {
      name: 'DINESH NAIK',
      role: 'President',
      description: 'The guiding force behind Visionaries, leading with innovation and purpose to shape every project with clarity and drive.',
      imagePath: image1,
    },
    {
      name: 'ADLINE MURAL RODRIGUES',
      role: 'Vice President',
      description: 'The creative strategist who bridges ideas and execution, ensuring Visionaries stays ahead of every trend.',
      imagePath: image2,
    },
    {
      name: 'AISHWARYA NAIK',
      role: 'Secretary',
      description: 'The organizer and communicator who keeps the flow of events and ideas seamless within the association.',
      imagePath: image3,
    },
    {
      name: 'NIKHIL SANKOLLI',
      role: 'Treasurer',
      description: 'The financial backbone managing resources smartly to fuel every Visionary dream.',
      imagePath: image4,
    },
    {
      name: 'MEGHA NAIK',
      role: 'Event Coordinator',
      description: 'The powerhouse of planning and creativity who ensures every Visionaries event is memorable and impactful.',
      imagePath: image5,
    },
  ];

  return (
    <div className="min-h-screen py-16 px-8 relative" style={{ zIndex: 10 }}>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto"
      >
        <h1 
          className="text-4xl md:text-6xl font-tech font-bold text-center mb-4 text-primary"
          style={{
            textShadow: '0 0 30px rgba(0, 188, 212, 0.5)',
          }}
        >
          CORE TEAM
        </h1>
        <p className="text-center text-muted-foreground mb-16 text-lg font-display">
          The minds shaping VISIONARIES 2025-26
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12 max-w-4xl mx-auto">
          <TeamMember {...teamData[0]} delay={0.1} />
          <TeamMember {...teamData[1]} delay={0.2} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <TeamMember {...teamData[2]} delay={0.3} />
          <TeamMember {...teamData[3]} delay={0.4} />
          <TeamMember {...teamData[4]} delay={0.5} />
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex justify-center mt-16"
        >
          <Button
            data-testid="button-back-to-home"
            onClick={handleBack}
            variant="outline"
            size="lg"
            className="px-8 py-6 text-lg font-display"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Home
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
