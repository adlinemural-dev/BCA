import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface TextRevealProps {
  onComplete: () => void;
}

export default function TextReveal({ onComplete }: TextRevealProps) {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    if (stage === 0) {
      const timer = setTimeout(() => setStage(1), 3500);
      return () => clearTimeout(timer);
    }
    if (stage === 1) {
      const timer = setTimeout(() => setStage(2), 1500);
      return () => clearTimeout(timer);
    }
    if (stage === 2) {
      const timer = setTimeout(() => setStage(3), 500);
      return () => clearTimeout(timer);
    }
    if (stage === 3) {
      const timer = setTimeout(() => onComplete(), 1500);
      return () => clearTimeout(timer);
    }
  }, [stage, onComplete]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center px-8" style={{ zIndex: 10 }}>
      <AnimatePresence mode="wait">
        {stage >= 0 && (
          <motion.div
            key="line1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mb-12"
          >
            <div className="overflow-hidden">
              <motion.h2
                className="text-xl md:text-2xl font-display font-medium text-foreground tracking-wide text-center"
                initial={{ width: 0 }}
                animate={{ width: '100%' }}
                transition={{ duration: 3, ease: 'linear' }}
                style={{
                  whiteSpace: 'nowrap',
                  display: 'inline-block',
                  borderRight: '3px solid rgba(0, 188, 212, 0.8)',
                  paddingRight: '4px',
                  textShadow: '0 0 20px rgba(0, 188, 212, 0.3)',
                }}
              >
                THE CLASS OF BCA 2025-26 PRESENTS
              </motion.h2>
            </div>
          </motion.div>
        )}

        {stage >= 1 && (
          <motion.div
            key="line2"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ 
              opacity: 1, 
              scale: [0.8, 1.05, 1],
            }}
            transition={{ duration: 0.8 }}
            className="mb-6"
          >
            <h1 
              className="text-5xl md:text-7xl lg:text-8xl font-tech font-bold text-primary text-center"
              style={{
                textShadow: '0 0 30px rgba(0, 188, 212, 0.6), 0 0 60px rgba(0, 188, 212, 0.4)',
              }}
            >
              VISIONARIES 2025-26
            </h1>
          </motion.div>
        )}

        {stage >= 2 && (
          <motion.div
            key="line3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ 
              opacity: 1, 
              y: 0,
            }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-lg md:text-xl font-display text-muted-foreground text-center tracking-wider">
              A GROUP OF TECHNO FREAKS
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
