import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Gamepad2, UserCheck, Sparkles, MonitorCheck, LucideIcon } from 'lucide-react';

interface WhatWeDoProps {
  onBack: () => void;
}

interface Activity {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
}

function ActivityCard({ activity, index }: { activity: Activity; index: number }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.15 }}
      whileHover={{ y: -8 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card 
        className="p-8 h-full hover-elevate transition-all duration-300"
        style={{
          boxShadow: isHovered ? '0 0 30px rgba(0, 188, 212, 0.3)' : undefined,
        }}
      >
        <div className="flex flex-col items-center text-center h-full">
          <motion.div 
            className="p-6 rounded-xl mb-6"
            style={{
              backgroundColor: activity.color,
            }}
            animate={{
              boxShadow: isHovered 
                ? `0 0 35px ${activity.color.replace('0.2', '0.6')}` 
                : `0 0 20px ${activity.color}`,
              scale: isHovered ? 1.1 : 1,
            }}
            transition={{ duration: 0.3 }}
          >
            <activity.icon className="h-12 w-12 text-primary" />
          </motion.div>
          
          <motion.h2 
            className="text-2xl font-tech font-bold text-foreground mb-4"
            animate={{
              textShadow: isHovered 
                ? '0 0 10px rgba(0, 188, 212, 0.6)' 
                : '0 0 0px rgba(0, 188, 212, 0)',
            }}
          >
            {activity.title}
          </motion.h2>
          
          <motion.div 
            className="h-0.5 mb-4"
            animate={{
              width: isHovered ? '100px' : '80px',
            }}
            transition={{ duration: 0.3 }}
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(0, 188, 212, 0.8), transparent)',
            }}
          />
          
          <p className="text-muted-foreground leading-relaxed flex-1">
            {activity.description}
          </p>
        </div>
      </Card>
    </motion.div>
  );
}

export default function WhatWeDo({ onBack }: WhatWeDoProps) {
  const playClickSound = () => {
    console.log('Click sound played');
  };

  const handleBack = () => {
    playClickSound();
    onBack();
  };

  const activities = [
    {
      icon: Gamepad2,
      title: 'Weekend Games',
      description: 'Fun and interactive sessions that combine learning with laughter, boosting creativity and teamwork.',
      color: 'rgba(0, 188, 212, 0.2)',
    },
    {
      icon: UserCheck,
      title: 'A Day With an Expert',
      description: 'Exclusive mentorship sessions with industry professionals to inspire and guide students.',
      color: 'rgba(0, 102, 255, 0.2)',
    },
    {
      icon: Sparkles,
      title: 'Enigma - Our Tech Fest',
      description: 'A celebration of technology, creativity, and innovation where ideas come alive.',
      color: 'rgba(0, 188, 212, 0.2)',
    },
    {
      icon: MonitorCheck,
      title: 'Tech Exhibition',
      description: 'A showcase of student-built projects and real-world innovations made by Visionaries members.',
      color: 'rgba(0, 102, 255, 0.2)',
    },
  ];

  return (
    <div className="min-h-screen py-16 px-8 relative" style={{ zIndex: 10 }}>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-6xl mx-auto"
      >
        <h1 
          className="text-4xl md:text-6xl font-tech font-bold text-center mb-4 text-primary"
          style={{
            textShadow: '0 0 30px rgba(0, 188, 212, 0.5)',
          }}
        >
          WHAT WE DO
        </h1>
        <p className="text-center text-muted-foreground mb-16 text-lg font-display">
          Empowering innovation through action
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {activities.map((activity, index) => (
            <ActivityCard key={index} activity={activity} index={index} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex justify-center mt-16"
        >
          <Button
            data-testid="button-back-to-home"
            onClick={handleBack}
            variant="outline"
            size="lg"
            className="px-8 py-6 text-lg font-display"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Home
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
