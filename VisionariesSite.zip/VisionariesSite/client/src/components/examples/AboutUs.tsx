import AboutUs from '../AboutUs';

export default function AboutUsExample() {
  return (
    <div className="bg-background">
      <AboutUs onBack={() => console.log('Back to home')} />
    </div>
  );
}
