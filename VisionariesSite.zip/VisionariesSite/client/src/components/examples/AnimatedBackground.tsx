import AnimatedBackground from '../AnimatedBackground';

export default function AnimatedBackgroundExample() {
  return <AnimatedBackground />;
}
