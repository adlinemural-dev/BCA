import NavigationButtons from '../NavigationButtons';

export default function NavigationButtonsExample() {
  return (
    <div className="bg-background min-h-screen flex items-center justify-center">
      <NavigationButtons onNavigate={(page) => console.log('Navigate to:', page)} />
    </div>
  );
}
