import RibbonCutting from '../RibbonCutting';

export default function RibbonCuttingExample() {
  return (
    <div className="bg-background min-h-screen">
      <RibbonCutting onComplete={() => console.log('Ribbon cut!')} />
    </div>
  );
}
