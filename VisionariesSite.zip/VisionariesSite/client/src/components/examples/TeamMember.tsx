import TeamMember from '../TeamMember';
import image1 from '@assets/1.jpg_1761971842024.jpeg';

export default function TeamMemberExample() {
  return (
    <div className="bg-background min-h-screen flex items-center justify-center p-8">
      <div className="max-w-sm">
        <TeamMember
          name="DINESH NAIK"
          role="President"
          description="The guiding force behind Visionaries, leading with innovation and purpose to shape every project with clarity and drive."
          imagePath={image1}
        />
      </div>
    </div>
  );
}
