import TeamMembers from '../TeamMembers';

export default function TeamMembersExample() {
  return (
    <div className="bg-background">
      <TeamMembers onBack={() => console.log('Back to home')} />
    </div>
  );
}
