import TextReveal from '../TextReveal';

export default function TextRevealExample() {
  return <TextReveal onComplete={() => console.log('Text reveal complete!')} />;
}
