import WhatWeDo from '../WhatWeDo';

export default function WhatWeDoExample() {
  return (
    <div className="bg-background">
      <WhatWeDo onBack={() => console.log('Back to home')} />
    </div>
  );
}
