import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import AnimatedBackground from '@/components/AnimatedBackground';
import RibbonCutting from '@/components/RibbonCutting';
import TextReveal from '@/components/TextReveal';
import NavigationButtons from '@/components/NavigationButtons';
import TeamMembers from '@/components/TeamMembers';
import AboutUs from '@/components/AboutUs';
import WhatWeDo from '@/components/WhatWeDo';

type Stage = 'ribbon' | 'text-reveal' | 'home' | 'team' | 'about' | 'activities';

export default function Home() {
  const [stage, setStage] = useState<Stage>('ribbon');

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <AnimatedBackground />
      
      <AnimatePresence mode="wait">
        {stage === 'ribbon' && (
          <motion.div
            key="ribbon"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
          >
            <RibbonCutting onComplete={() => setStage('text-reveal')} />
          </motion.div>
        )}

        {stage === 'text-reveal' && (
          <motion.div
            key="text-reveal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <TextReveal onComplete={() => setStage('home')} />
          </motion.div>
        )}

        {stage === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="fixed inset-0 flex flex-col items-center justify-center" style={{ zIndex: 10 }}>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="mb-32"
              >
                <h1 
                  className="text-5xl md:text-7xl lg:text-8xl font-tech font-bold text-primary text-center mb-6"
                  style={{
                    textShadow: '0 0 30px rgba(0, 188, 212, 0.6), 0 0 60px rgba(0, 188, 212, 0.4)',
                  }}
                >
                  VISIONARIES 2025-26
                </h1>
                <p className="text-lg md:text-xl font-display text-muted-foreground text-center tracking-wider">
                  A GROUP OF TECHNO FREAKS
                </p>
              </motion.div>
            </div>
            <NavigationButtons onNavigate={(page) => setStage(page)} />
          </motion.div>
        )}

        {stage === 'team' && (
          <motion.div
            key="team"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
          >
            <TeamMembers onBack={() => setStage('home')} />
          </motion.div>
        )}

        {stage === 'about' && (
          <motion.div
            key="about"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
          >
            <AboutUs onBack={() => setStage('home')} />
          </motion.div>
        )}

        {stage === 'activities' && (
          <motion.div
            key="activities"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
          >
            <WhatWeDo onBack={() => setStage('home')} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
