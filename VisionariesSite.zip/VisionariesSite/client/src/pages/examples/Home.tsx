import Home from '../Home';

export default function HomeExample() {
  return <Home />;
}
