# VISIONARIES BCA Association - Design Guidelines

## Design Approach
**Custom Tech-Themed Experience** - This project requires a unique, cinematic dark tech aesthetic with custom interactive elements and animations. The design prioritizes visual impact and user engagement through animated transitions and interactive elements.

---

## Color Palette
**Dark Tech Theme** (NO neon, NO gradients)
- **Background**: Deep dark (#0a0a0a to #1a1a1a range)
- **Primary Accents**: Cyan (#00bcd4), Electric Blue (#0066ff), Bright White (#ffffff)
- **Supporting Colors**: Tech-inspired blues and whites with subtle glows
- **Text**: Bright white for headings, light gray for body text

---

## Typography System

**Font Selection:**
- Primary: Bold, futuristic sans-serif (e.g., "Orbitron", "Rajdhani", "Exo 2")
- Secondary: Modern, clean sans-serif for body text

**Hierarchy:**
- Hero Title ("VISIONARIES 2025-26"): 4xl-6xl, bold, with subtle glow effect
- Section Headers: 2xl-3xl, bold
- Subheadings: xl-2xl, medium weight
- Body Text: base-lg, regular weight
- Button Text: base-lg, medium weight

---

## Layout System

**Spacing Units**: Tailwind scale of 4, 6, 8, 12, 16, 20, 24
- Section padding: py-16 to py-24
- Component spacing: gap-8 to gap-12
- Card padding: p-6 to p-8

**Page Structure:**
1. **Page 1 - Ribbon Cutting**: Full viewport (100vh), centered animation
2. **Page 2 - Text Reveal**: Full viewport initially, then reveals navigation
3. **Content Pages**: Natural height with consistent section padding

---

## Component Library

### Navigation Buttons
- Three primary buttons: "Team Members", "About Us", "What We Do"
- Styling: Soft glow effect (NOT neon), hover scaling animation
- Size: Generous padding (px-8 py-4), medium-large text
- Spacing: Horizontal layout with gap-6

### Team Member Cards
**Hierarchical Layout:**
- **Top Row (Centered)**: President + Vice President (2 columns)
- **Bottom Row (Centered)**: Secretary, Treasurer, Event Coordinator (3 columns)

**Card Structure:**
- Profile image: Circular or rounded square, consistent aspect ratio (1:1)
- Image size: 200-250px width on desktop
- Designation: Small caps or bold, above name
- Name: Medium-large text, prominent
- Description: 2-3 lines, readable size
- Glow divider below image

### Content Cards (About Us, What We Do)
- Clean, scrollable layout
- Glowing horizontal dividers between sections
- Generous padding and line-height for readability
- Icons for "What We Do" activities

### Back to Home Button
- Consistent placement at bottom of each content page
- Similar styling to navigation buttons
- Clear visual hierarchy

---

## Animations & Transitions

### Page 1 - Ribbon Cutting
- Ribbon: Horizontal stretched across screen, center aligned
- Scissors: Draggable element, positioned beside ribbon
- Interaction: Drag scissors to ribbon triggers cut animation
- Transition: Cinematic fade or ripple effect to Page 2

### Page 2 - Text Reveal
**Sequence (with timing):**
1. "THE CLASS OF BCA 2025-26 PRESENTS" - Typing effect with faint glow
2. Wait 1.5 seconds
3. "VISIONARIES 2025-26" - Scale-up/pulse animation, hero emphasis
4. Wait 0.5 seconds  
5. "A GROUP OF TECHNO FREAKS" - Fade-in or subtle glitch effect

### Micro-Interactions
- Button hover: Smooth scale (1.05x) + enhanced glow
- Button click: Soft click sound effect
- Page transitions: Smooth fade, slide, or glitch effects (300-500ms)
- Back button: Reverse transition animation

### Performance
- Minimize heavy animations
- Use CSS transforms for smooth 60fps
- Optimize animated background for performance

---

## Background Treatment

**Live Animated Wallpaper** (Choose ONE):
- Glowing circuit lines (subtle, slow-moving)
- Binary rain effect (Matrix-style, low opacity)
- Pulsing neon grids (geometric, rhythmic)

**Implementation:**
- Fixed position, covers viewport
- Low opacity to not overwhelm content
- Smooth, continuous loop
- Minimal performance impact

---

## Images

**Team Member Photos:**
- 5 photos provided in sequence:
  1. President - Dinesh Naik
  2. Vice President - Adline Mural Rodrigues  
  3. Secretary - Aishwarya Naik
  4. Treasurer - Nikhil Sankolli
  5. Event Coordinator - Megha Naik

**Aspect Ratio**: 1:1 (square) or 4:5 (portrait)
**Treatment**: Circular crop or rounded corners (rounded-2xl), subtle border glow
**Responsive**: Scale proportionally, maintain hierarchy on mobile (stack vertically)

---

## Sound Effects

- **Button Clicks**: Soft, subtle tech click sound
- **NO ribbon cut sound** (silent animation)

---

## Responsive Behavior

**Desktop (lg+):**
- Team hierarchy: 2 top, 3 bottom
- Navigation: Horizontal button layout
- Full animated background

**Tablet (md):**
- Team cards: 2 columns max
- Maintain animations
- Adjusted spacing

**Mobile (base):**
- Team cards: Single column stack
- Buttons: Stack vertically or wrap
- Simplified background animation
- Maintain readability

---

## Critical Requirements

✓ Dark tech theme with NO gradients
✓ Colors: Tech blues, cyan, white (NOT neon style)
✓ Animated background (circuits/binary/grid)
✓ Cinematic transitions between all pages
✓ Interactive ribbon cutting (Page 1)
✓ Timed text reveal sequence (Page 2)
✓ Hierarchical team layout with provided photos
✓ Smooth hover/click interactions
✓ Back to Home navigation on all content pages
✓ Sound effects on button clicks only
✓ Professional, modern, tech-forward aesthetic